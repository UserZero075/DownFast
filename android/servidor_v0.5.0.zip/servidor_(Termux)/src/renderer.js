let i = typeof localStorage.getItem('index') === 'number' ? localStorage.getItem('index') : 0
const socket = io('http://localhost:7569');

const sendLink = (link) => {
  if (link.trim() !== '' && i <= 4) {
    i++
    localStorage.setItem('index', i)
    ID = generateRandomID(50)
    socket.emit('link_download', JSON.stringify({
      link,
      ID
    }));
    linkInput.value = '';
    createDownloadItem(link, ID)
  }
}

const tabButton = document.getElementById('tabButton');
const modal = document.getElementById('modal');
const linkInput = document.getElementById('linkInput');
const addLinkButton = document.getElementById('addLinkButton2');
const cancelButton = document.getElementById('cancelButton2');

tabButton.addEventListener('click', () => {
  modal.style.display = 'flex';
});

addLinkButton.addEventListener('click', () => {
  const link = linkInput.value.trim();
  if (link !== '') {
    sendLink(link)
    linkInput.value = ''; 
    modal.style.display = 'none';
  }
});

cancelButton.addEventListener('click', () => {
  modal.style.display = 'none';
});

// Cerrar el modal si se toca fuera de él
window.addEventListener('click', (event) => {
  if (event.target === modal) {
    modal.style.display = 'none';
  }
});

const $ = selector => document.querySelector(selector)
let start
let downloadItem;
let downloadProcess;
let ID;
const dataItem = {}

const generateRandomID = (length) => {
  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let randomID = '';
  for (let i = 0; i < length; i++) {
    const randomIndex = Math.floor(Math.random() * characters.length);
    randomID += characters.charAt(randomIndex);
  }
  return randomID; 
}

const createDownloadItem = (link, id) => {
  // Crear el elemento div principal
  let downloadBlock = document.createElement('div');
  downloadBlock.classList.add('download-block');
  downloadBlock.id = id

  // Crear el elemento div para la barra de progreso
  let progressDiv = document.createElement('div');
  progressDiv.classList.add('progress');

  // Crear la barra de progreso
  let progressBar = document.createElement('div');
  progressBar.id = 'progressBar'
  progressBar.classList.add('progress-bar', 'progress-bar-animated', 'progress-bar-striped');
  progressBar.setAttribute('role', 'progressbar');
  progressBar.style.width = '0%';
  progressBar.setAttribute('aria-valuenow', '0');
  progressBar.setAttribute('aria-valuemin', '0');
  progressBar.setAttribute('aria-valuemax', '100');
  progressBar.innerHTML = '<strong>0%</strong>';

  // Añadir la barra de progreso al div de progreso
  progressDiv.appendChild(progressBar);

  // Crear el div para la información del archivo
  let fileInfoDiv = document.createElement('div');
  fileInfoDiv.id = 'fileinfo'
  fileInfoDiv.className = "file-info";
  fileInfoDiv.innerHTML = '<p>Archivo: <strong>Procesando...</strong></p>' +
                          '<p>Tamaño: <strong>Procesando...</strong></p>' +
                          '<strong style="color: gray;">0 KB / Procesando...</strong>';

  const cancelButton = document.createElement("button");
  cancelButton.id = 'cancelButton';
  cancelButton.style = 'visibility: hidden;'
  cancelButton.className = "btn btn-danger btn-action";
  cancelButton.innerHTML = 'Cancelar';
  cancelButton.addEventListener("click", function() {
    start = false
    localStorage.setItem('start', 'false');
    socket.emit('cancel', id)
    i--;
    localStorage.setItem('index', i)
    const downloadItems = localStorage.getItem('downloadItems') != null ? JSON.parse(localStorage.getItem('downloadItems')) : []
      downloadItems.splice(downloadItems.findIndex(data => {data.id === id}), 1)
      localStorage.setItem('downloadItems', JSON.stringify(downloadItems));
    downloadItem.remove()
  });
  
  const pauseButton = document.createElement("button");
  pauseButton.id = 'pausedButton';
  pauseButton.style = 'visibility: hidden;'
  pauseButton.className = "btn btn-danger btn-action";
  pauseButton.innerHTML = 'Pausar';
  pauseButton.addEventListener("click", function() {
    if (pauseButton.id === 'pausedButton') {
      socket.emit('cancel', id)
      dataItem[id][0].date = '';
      pauseButton.className = "btn btn-primary btn-action";
      pauseButton.id = 'reanudedButton';
      pauseButton.innerHTML = 'Reanudar';
      const downloadItems = localStorage.getItem('downloadItems') != null ? JSON.parse(localStorage.getItem('downloadItems')) : []
      downloadItems.push({
        filename: dataItem[id][0].filename,
        sizeMetadata: dataItem[id][0].sizeMetadata,
        progressBarInner: dataItem[id][0].progressBarInner,
        progressDetails: dataItem[id][0].progressDetails,
        date: dataItem[id][0].date,
        link,
        id, downloadItem: 
        `<div class="download-block" id="${id}">
            <div class="progress">
                <div class="progress-bar progress-bar-animated progress-bar-striped" role="progressbar" id="progressBar" style="width: ${dataItem[id][0].progressBarInner}%" aria-valuenow="${dataItem[id][0].progressBarInner}" aria-valuemin="0" aria-valuemax="100"><strong>${dataItem[id][0].progressBarInner}% 4.8MB/s</strong></div>
            </div>
            <div class="file-info" id="fileinfo">
                <p>Archivo: <strong>${dataItem[id][0].filename}</strong></p>
                <p>Tamaño: <strong>${dataItem[id][0].sizeMetadata}</strong></p>
                <strong style="color: gray;">${dataItem[id][0].progressDetails}</strong>
            </div>
            <button class="btn btn-danger btn-action" id="cancelButton">Cancelar</button>
            <button class="btn btn-primary btn-action" id="reanudedButton">Reanudar</button>
        </div>`
      })
      localStorage.setItem('downloadItems', JSON.stringify(downloadItems));
    } else {
      socket.emit('link_download', JSON.stringify({
        link,
        filename: dataItem[id][0].filename,
        ID: id
      }));
      pauseButton.id = 'pausedButton';
      pauseButton.className = "btn btn-danger btn-action";
      pauseButton.innerHTML = 'Pausar';
      const downloadItems = localStorage.getItem('downloadItems') != null ? JSON.parse(localStorage.getItem('downloadItems')) : []
      downloadItems.splice(downloadItems.findIndex(data => {data.id === id}), 1)
      localStorage.setItem('downloadItems', JSON.stringify(downloadItems));
    }
  });

  // Añadir todos los elementos al bloque de descarga
  downloadBlock.appendChild(progressDiv);
  downloadBlock.appendChild(fileInfoDiv);
  downloadBlock.appendChild(cancelButton);
  downloadBlock.appendChild(pauseButton);

  // Añadir el bloque de descarga al elemento html especificado
  let container = document.querySelector('.col-lg-6.offset-lg-3');
  container.appendChild(downloadBlock);
  if (container) {
    container.appendChild(downloadBlock);
  } else {
    console.error("No se encontró el elemento .col-lg-6.offset-lg-3 en el documento.");
  }
}

document.addEventListener("visibilitychange", function() {
  if (document.visibilityState === 'hidden') {} else {
    socket.connect();
  }
});

socket.on('message_error', (data) => {
  data = JSON.parse(data);
  if (document.getElementById(`${data.ID}`)) {
    downloadItem = document.getElementById(`${data.ID}`)
  }
  const cancelButton = downloadItem.querySelector('#cancelButton');
  const pausedButton = downloadItem.querySelector('#pausedButton');

  if (data.message === 'Reintentando...') {
    cancelButton.style = 'visibility: visible;';
    pausedButton.style = 'visibility: hidden;';
  } else if (data.message === 'Error en el código...') {
    cancelButton.style = 'visibility: visible;';
    cancelButton.textContent = 'Eliminar'
    pausedButton.remove()
  } else {
    cancelButton.style = 'visibility: visible;';
    cancelButton.textContent = 'Eliminar'
    pausedButton.remove()
  }

  if (data.message === 'Error en el código...') {
    const progressDetails = downloadItem.querySelector('#fileinfo');
    progressDetails.innerHTML = `<p>Estado: <strong>${data.message}</strong></p>
    <strong style="color: gray;">${data.error}</strong>`;
  } else {
    const progressDetails = downloadItem.querySelector('#fileinfo');
    progressDetails.innerHTML = `<p>Estado: <strong>${data.message}</strong></p>`;
  }
});


socket.on('downloading', (data) => {
  data = JSON.parse(data);
  if (document.getElementById(`${data.ID}`)) {
    downloadItem = document.getElementById(`${data.ID}`)
  } else {
    createDownloadItem(data.link ,`${data.ID}`)
    downloadItem = document.getElementById(`${data.ID}`)
  }
  dataItem[`${data.ID}`] = []
  dataItem[`${data.ID}`].push({
    filename: data.fileName.split('-')[0].length > 25 ? data.fileName.split('-')[0].substring(0, 25) : data.fileName.split('-')[0],
    progressBarInner: ((data.transferred / (1024*1024)).toFixed(2) / Number(data.total.replace(' MB', '')) * 100).toFixed(1),
    sizeMetadata: data.total,
    progressDetails: ((data.transferred / (1024*1024)).toFixed(2) / Number(data.total.replace(' MB', '')) * 100).toFixed(0) > 35 ? `${(data.transferred / (1024*1024)).toFixed(2)} MB / ${data.total}` :`${(data.transferred / (1024*1024)).toFixed(2)} MB / ${data.total} | ${((data.transferred / (1024*1024)).toFixed(2) / Number(data.total.replace(' MB', '')) * 100).toFixed(1)}% ${(data.speed / (1024*1024)).toFixed(2)}MB/s`, 
  })
  const cancelButton = downloadItem.querySelector('#cancelButton');
  const pausedButton = downloadItem.querySelector('#pausedButton');
  cancelButton.style = 'visibility: visible;';
  pausedButton.style = 'visibility: visible;';
  const progressDetails = downloadItem.querySelector('#fileinfo');
  const progressBarInner = downloadItem.querySelector('#progressBar');

  if (((data.transferred / (1024*1024)).toFixed(2) / Number(data.total.replace(' MB', '')) * 100).toFixed(0) >= 99) {
    console.log('dsdsd')
    i--
    localStorage.setItem('index', i)
    cancelButton.remove()
    pausedButton.remove()
    progressBarInner.style.width = `100%`;
    progressBarInner.innerHTML = `100% ${(data.speed / (1024*1024)).toFixed(2)}MB/s Terminado`;
    progressDetails.innerHTML = `<p>Archivo: <strong>${data.fileName.split('-')[0].length > 25 ? data.fileName.split('-')[0].substring(0, 25) : data.fileName.split('-')[0]}</strong></p>
    <p>Tamaño: <strong>${data.total}</strong></p>
    <strong style="color: gray;">${data.total} / ${data.total}</strong>`;
  } else {
    progressBarInner.style.width = `${((data.transferred / (1024*1024)).toFixed(2) / Number(data.total.replace(' MB', '')) * 100).toFixed(0)}%`;
    progressBarInner.innerHTML = `${((data.transferred / (1024*1024)).toFixed(2) / Number(data.total.replace(' MB', '')) * 100).toFixed(1)}% ${(data.speed / (1024*1024)).toFixed(2)}MB/s`;
  }

  if (((data.transferred / (1024*1024)).toFixed(2) / Number(data.total.replace(' MB', '')) * 100).toFixed(0) > 35) {
    progressDetails.innerHTML = `<p>Archivo: <strong>${data.fileName.split('-')[0].length > 25 ? data.fileName.split('-')[0].substring(0, 25) : data.fileName.split('-')[0]}</strong></p>
    <p>Tamaño: <strong>${data.total}</strong></p>
    <strong style="color: gray;">${(data.transferred / (1024*1024)).toFixed(2)} MB / ${data.total}</strong>`;
  } else {
    progressDetails.innerHTML = `<p>Archivo: <strong>${data.fileName.split('-')[0].length > 25 ? data.fileName.split('-')[0].substring(0, 25) : data.fileName.split('-')[0]}</strong></p>
    <p>Tamaño: <strong>${data.total}</strong></p>
    <strong style="color: gray;">${(data.transferred / (1024*1024)).toFixed(2)} MB / ${data.total} | ${((data.transferred / (1024*1024)).toFixed(2) / Number(data.total.replace(' MB', '')) * 100).toFixed(1)}% ${(data.speed / (1024*1024)).toFixed(2)}MB/s</strong>`;
  }
});


const reconnect = () => {
  socket.connect();
}

const downloadsSection = document.querySelector(".col-lg-6");

for (let index in JSON.parse(localStorage.getItem('downloadItems'))) {
  if (downloadsSection) {
    let downloadItem = JSON.parse(localStorage.getItem('downloadItems'))[index].downloadItem
    let id = JSON.parse(localStorage.getItem('downloadItems'))[index].id
    let filename = JSON.parse(localStorage.getItem('downloadItems'))[index].filename
    let progressBarInner = JSON.parse(localStorage.getItem('downloadItems'))[index].progressBarInner
    let progressDetails = JSON.parse(localStorage.getItem('downloadItems'))[index].progressDetails
    let sizeMetadata = JSON.parse(localStorage.getItem('downloadItems'))[index].sizeMetadata
    let date = JSON.parse(localStorage.getItem('downloadItems'))[index].date
    let link = JSON.parse(localStorage.getItem('downloadItems'))[index].link
    downloadsSection.innerHTML += downloadItem

    downloadItem = document.getElementById(`${id}`)

    const cancelButton = downloadItem.querySelector('#cancelButton');
    cancelButton.textContent = "Cancelar";

    const pausedButton = downloadItem.querySelector("#reanudedButton");
    
    cancelButton.addEventListener("click", function() {
      start = false
      localStorage.setItem('start', 'false');
      i--;
      localStorage.setItem('index', i)
      const downloadItems = localStorage.getItem('downloadItems') != null ? JSON.parse(localStorage.getItem('downloadItems')) : []
      downloadItems.splice(downloadItems.findIndex(data => {data.id === id}), 1)
      localStorage.setItem('downloadItems', JSON.stringify(downloadItems));
      downloadItem.remove()
    });

    pausedButton.addEventListener("click", function() {
      if (pausedButton.id === 'pausedButton') {
        socket.emit('cancel', id)      
        pausedButton.className = "btn btn-primary btn-action";
        dataItem[id][0].date = date;
        pausedButton.id = 'reanudedButton';
        pausedButton.textContent = 'Reanudar';
        const downloadItems = localStorage.getItem('downloadItems') != null ? JSON.parse(localStorage.getItem('downloadItems')) : []
        downloadItems.push({
          filename,
          sizeMetadata,
          progressBarInner,
          progressDetails,
          date,
          link,
          id, downloadItem: 
          `<div class="download-block" id="${id}">
              <div class="progress">
                  <div class="progress-bar progress-bar-animated progress-bar-striped" role="progressbar" id="progressBar" style="width: ${dataItem[id][0].progressBarInner}%" aria-valuenow="${dataItem[id][0].progressBarInner}" aria-valuemin="0" aria-valuemax="100"><strong>${dataItem[id][0].progressBarInner}% 4.8MB/s</strong></div>
              </div>
              <div class="file-info" id="fileinfo">
                  <p>Archivo: <strong>${dataItem[id][0].filename}</strong></p>
                  <p>Tamaño: <strong>${dataItem[id][0].sizeMetadata}</strong></p>
                  <strong style="color: gray;">${dataItem[id][0].progressDetails}</strong>
              </div>
              <button class="btn btn-danger btn-action" id="cancelButton">Cancelar</button>
              <button class="btn btn-primary btn-action" id="reanudedButton">Reanudar</button>
          </div>`
        })
        localStorage.setItem('downloadItems', JSON.stringify(downloadItems));
      } else {
        socket.emit('link_download', JSON.stringify({
          link,
          filename,
          ID: id
        }));
        pausedButton.id = 'pausedButton';
        pausedButton.className = "btn btn-danger btn-action";
        pausedButton.textContent = "Pausar";
        const downloadItems = localStorage.getItem('downloadItems') != null ? JSON.parse(localStorage.getItem('downloadItems')) : []
        downloadItems.splice(downloadItems.findIndex(data => {data.id === id}), 1)
        localStorage.setItem('downloadItems', JSON.stringify(downloadItems));
      }
    });
  } else {
    console.error("No se encontró el elemento .downloads-section en el documento.");
  }
}
