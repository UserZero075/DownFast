const $ = selector => document.querySelector(selector)
const socket = io('http://localhost:7569');
let start
let downloadItem;
let downloadProcess;
let ID;
const dataItem = {}

let i = typeof localStorage.getItem('index') === 'number' ? localStorage.getItem('index') : 0

const generateRandomID = (length) => {
  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let randomID = '';
  for (let i = 0; i < length; i++) {
    const randomIndex = Math.floor(Math.random() * characters.length);
    randomID += characters.charAt(randomIndex);
  }
  return randomID;
}

const createDownloadItem = (link, id) => {
  const downloadItem = document.createElement("div");
  downloadItem.className = "download-item";
  downloadItem.id = id

  const downloadInfo = document.createElement("div");
  downloadInfo.className = "download-info";

  const detailsContainer = document.createElement("div");
  detailsContainer.className = "details-container";

  const title = document.createElement("h3");
  title.id = 'title';
  title.className = "title";
  title.textContent = "Procesando...";

  const sizeMetadata = document.createElement("p");
  sizeMetadata.id = 'sizeMetadata'
  sizeMetadata.className = "metadata";
  sizeMetadata.textContent = "Tamaño: procesando...";

  const dateMetadata = document.createElement("p");
  dateMetadata.className = "metadata";
  let fecha = new Date(); 
  let dia = fecha.getDate(); 
  let mes = fecha.getMonth() + 1; 
  let year = fecha.getFullYear();
  let fechaFormateada = dia + '-' + mes + '-' + year;
  dateMetadata.textContent = `Fecha de Descarga: ${fechaFormateada}`;

  detailsContainer.appendChild(title);
  detailsContainer.appendChild(sizeMetadata);
  detailsContainer.appendChild(dateMetadata);
  downloadInfo.appendChild(detailsContainer);

  const progressContainer = document.createElement("div");
  progressContainer.className = "progress-container";

  const progressBar = document.createElement("div");
  progressBar.className = "progress progress-striped active";
  const progressBarInner = document.createElement("div");
  progressBarInner.className = "progress-bar progress-bar-inverse";
  progressBarInner.id = "progressBarInner";
  progressBarInner.setAttribute("role", "progressbar");
  progressBarInner.setAttribute("aria-valuenow", "0");
  progressBarInner.setAttribute("aria-valuemin", "0");
  progressBarInner.setAttribute("aria-valuemax", "100");
  progressBarInner.style.width = "0%";
  progressBar.appendChild(progressBarInner);

  const progressDetails = document.createElement("p");
  progressDetails.id = 'progressDetails';
  progressDetails.className = "progress-details";
  progressDetails.textContent = "Hilos: 0 | 0 MB / 0 MB";

  const cancelButton = document.createElement("button");
  cancelButton.id = 'cancelButton';
  cancelButton.className = "cancel-button";
  cancelButton.style = 'visibility: hidden;'
  cancelButton.textContent = "Cancelar";

  const pausedButton = document.createElement("button");
  pausedButton.id = 'pausedButton';
  pausedButton.className = "paused-button";
  pausedButton.style = 'visibility: hidden;'
  pausedButton.textContent = "Pausar";
  
  cancelButton.addEventListener("click", function() {
    start = false
    localStorage.setItem('start', 'false');
    socket.emit('cancel', id)
    i--;
    localStorage.setItem('index', i)
    const downloadItems = localStorage.getItem('downloadItems') != null ? JSON.parse(localStorage.getItem('downloadItems')) : []
      downloadItems.splice(downloadItems.findIndex(data => {data.id === id}), 1)
      localStorage.setItem('downloadItems', JSON.stringify(downloadItems));
    downloadItem.remove()
  });

  pausedButton.addEventListener("click", function() {
    if (pausedButton.id === 'pausedButton') {
      socket.emit('cancel', id)
      dataItem[id][0].date = fechaFormateada;
      pausedButton.className = "reanuded-button";
      pausedButton.id = 'reanudedButton';
      pausedButton.textContent = 'Reanudar';
      const downloadItems = localStorage.getItem('downloadItems') != null ? JSON.parse(localStorage.getItem('downloadItems')) : []
      downloadItems.push({
        filename: dataItem[id][0].filename,
        sizeMetadata: dataItem[id][0].sizeMetadata,
        progressBarInner: dataItem[id][0].progressBarInner,
        progressDetails: dataItem[id][0].progressDetails,
        date: dataItem[id][0].date,
        link,
        id, downloadItem: 
        `<div class="download-item" id="${id}" ><div class="download-info"><div class="details-container"><h3 id="title" class="title">${dataItem[id][0].filename}</h3><p id="sizeMetadata" class="metadata">Tamaño: ${dataItem[id][0].sizeMetadata}</p><p class="metadata">Fecha de Descarga: ${dataItem[id][0].date}</p></div></div><div class="progress-container"><div class="progress progress-striped active"><div class="progress-bar progress-bar-inverse" id="progressBarInner" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: ${dataItem[id][0].progressBarInner}%;">${dataItem[id][0].progressBarInner}% 0.08MB/s</div></div><p id="progressDetails" class="progress-details">${dataItem[id][0].progressDetails}</p><button id="cancelButton" class="cancel-button" style="visibility: visible;">Cancelar</button><button id="reanudedButton" class="reanuded-button" style="visibility: visible;">Reanudar</button></div></div>`,
      })
      localStorage.setItem('downloadItems', JSON.stringify(downloadItems));
    } else {
      socket.emit('link_download', JSON.stringify({
        link,
        filename: dataItem[id][0].filename,
        ID: id
      }));
      pausedButton.id = 'pausedButton';
      pausedButton.className = "paused-button";
      pausedButton.textContent = "Pausar";
      const downloadItems = localStorage.getItem('downloadItems') != null ? JSON.parse(localStorage.getItem('downloadItems')) : []
      downloadItems.splice(downloadItems.findIndex(data => {data.id === id}), 1)
      localStorage.setItem('downloadItems', JSON.stringify(downloadItems));
    }
  });

  progressContainer.appendChild(progressBar);
  progressContainer.appendChild(progressDetails);
  progressContainer.appendChild(cancelButton);
  progressContainer.appendChild(pausedButton);

  downloadItem.appendChild(downloadInfo);
  downloadItem.appendChild(progressContainer);

  const downloadsSection = document.querySelector(".downloads-section");

  if (downloadsSection) {
    downloadsSection.appendChild(downloadItem);
  } else {
    console.error("No se encontró el elemento .downloads-section en el documento.");
  }
}

document.addEventListener("visibilitychange", function() {
  if (document.visibilityState === 'hidden') {} else {
    socket.connect();
  }
});


socket.on('downloading', (data) => {
  data = JSON.parse(data);
  if (document.getElementById(`${data.ID}`)) {
    downloadItem = document.getElementById(`${data.ID}`)
  } else {
    createDownloadItem(data.link ,`${data.ID}`)
    downloadItem = document.getElementById(`${data.ID}`)
  }
  dataItem[`${data.ID}`] = []
  dataItem[`${data.ID}`].push({
    filename: data.fileName.split('-')[0].length > 25 ? data.fileName.split('-')[0].substring(0, 25) : data.fileName.split('-')[0],
    progressBarInner: ((data.transferred / (1024*1024)).toFixed(2) / Number(data.total.replace(' MB', '')) * 100).toFixed(1),
    sizeMetadata: data.total,
    progressDetails: ((data.transferred / (1024*1024)).toFixed(2) / Number(data.total.replace(' MB', '')) * 100).toFixed(0) > 35 ? `Hilos: ${data.numberThreads} | ${(data.transferred / (1024*1024)).toFixed(2)} MB / ${data.total}` :`Hilos: ${data.numberThreads} | ${(data.transferred / (1024*1024)).toFixed(2)} MB / ${data.total} | ${((data.transferred / (1024*1024)).toFixed(2) / Number(data.total.replace(' MB', '')) * 100).toFixed(1)}% ${(data.speed / (1024*1024)).toFixed(2)}MB/s`, 
  })
  const cancelButton = downloadItem.querySelector('#cancelButton');
  const pausedButton = downloadItem.querySelector('#pausedButton');
  cancelButton.style = 'visibility: visible;'
  pausedButton.style = 'visibility: visible;'
  const progressDetails = downloadItem.querySelector('#progressDetails');
  const progressBarInner = downloadItem.querySelector('.progress-bar-inverse');
  const sizeMetadata = downloadItem.querySelector('#sizeMetadata');
  const title = downloadItem.querySelector('#title');

  if (((data.transferred / (1024*1024)).toFixed(2) / Number(data.total.replace(' MB', '')) * 100).toFixed(0) >= 98) {
    i--
    localStorage.setItem('index', i)
    cancelButton.remove()
    progressBarInner.style.width = `100%`;
    progressBarInner.innerHTML = `100% ${(data.speed / (1024*1024)).toFixed(2)}MB/s Terminado`;
    progressDetails.innerHTML = `Hilos: ${data.numberThreads} | ${data.total} / ${data.total}`;
  } else {
    progressBarInner.style.width = `${((data.transferred / (1024*1024)).toFixed(2) / Number(data.total.replace(' MB', '')) * 100).toFixed(0)}%`;
    progressBarInner.innerHTML = `${((data.transferred / (1024*1024)).toFixed(2) / Number(data.total.replace(' MB', '')) * 100).toFixed(1)}% ${(data.speed / (1024*1024)).toFixed(2)}MB/s`;
  }

  title.innerHTML = data.fileName.split('-')[0].length > 25 ? data.fileName.split('-')[0].substring(0, 25) : data.fileName.split('-')[0]
  sizeMetadata.innerHTML = 'Tamaño: ' + data.total;
  if (((data.transferred / (1024*1024)).toFixed(2) / Number(data.total.replace(' MB', '')) * 100).toFixed(0) > 35) {
    progressDetails.innerHTML = `Hilos: ${data.numberThreads} | ${(data.transferred / (1024*1024)).toFixed(2)} MB / ${data.total}`;
  } else {
    progressDetails.innerHTML = `Hilos: ${data.numberThreads} | ${(data.transferred / (1024*1024)).toFixed(2)} MB / ${data.total} | ${((data.transferred / (1024*1024)).toFixed(2) / Number(data.total.replace(' MB', '')) * 100).toFixed(1)}% ${(data.speed / (1024*1024)).toFixed(2)}MB/s`;
  }
});


const reconnect = () => {
  socket.connect();
}

const sendLink = () => {
  const linkInput = document.getElementById('linkElement');
  const link = linkInput.value.trim();
  if (link.trim() !== '' && i <= 4) {
    i++
    localStorage.setItem('index', i)
    ID = generateRandomID(50)
    socket.emit('link_download', JSON.stringify({
      link,
      ID
    }));
    linkInput.value = '';
    createDownloadItem(link, ID)
  }
}


const downloadsSection = document.querySelector(".downloads-section");

for (let index in JSON.parse(localStorage.getItem('downloadItems'))) {
  if (downloadsSection) {
    let downloadItem = JSON.parse(localStorage.getItem('downloadItems'))[index].downloadItem
    let id = JSON.parse(localStorage.getItem('downloadItems'))[index].id
    let filename = JSON.parse(localStorage.getItem('downloadItems'))[index].filename
    let progressBarInner = JSON.parse(localStorage.getItem('downloadItems'))[index].progressBarInner
    let progressDetails = JSON.parse(localStorage.getItem('downloadItems'))[index].progressDetails
    let sizeMetadata = JSON.parse(localStorage.getItem('downloadItems'))[index].sizeMetadata
    let date = JSON.parse(localStorage.getItem('downloadItems'))[index].date
    let link = JSON.parse(localStorage.getItem('downloadItems'))[index].link
    downloadsSection.innerHTML += downloadItem

    downloadItem = document.getElementById(`${id}`)

    const cancelButton = downloadItem.querySelector('#cancelButton');
    cancelButton.textContent = "Cancelar";

    const pausedButton = downloadItem.querySelector("#reanudedButton");
    
    cancelButton.addEventListener("click", function() {
      start = false
      localStorage.setItem('start', 'false');
      i--;
      socket.emit('cancel', id)
      localStorage.setItem('index', i)
      const downloadItems = localStorage.getItem('downloadItems') != null ? JSON.parse(localStorage.getItem('downloadItems')) : []
      downloadItems.splice(downloadItems.findIndex(data => {data.id === id}), 1)
      localStorage.setItem('downloadItems', JSON.stringify(downloadItems));
      downloadItem.remove()
    });

    pausedButton.addEventListener("click", function() {
      if (pausedButton.id === 'pausedButton') {
        socket.emit('cancel', id)
        pausedButton.className = "reanuded-button";
        dataItem[id][0].date = date;
        pausedButton.id = 'reanudedButton';
        pausedButton.textContent = 'Reanudar';
        const downloadItems = localStorage.getItem('downloadItems') != null ? JSON.parse(localStorage.getItem('downloadItems')) : []
        downloadItems.push({
          filename,
          sizeMetadata,
          progressBarInner,
          progressDetails,
          date,
          link,
          id, downloadItem: 
          `<div class="download-item" id="${id}">
            <div class="download-info">
              <div class="details-container">
                <h3 id="title" class="title">${dataItem[id][0].filename === undefined || null ? filename : dataItem[id][0].filename}</h3>
                <p id="sizeMetadata" class="metadata">Tamaño: ${dataItem[id][0].sizeMetadata === undefined || null ? sizeMetadata : dataItem[id][0].sizeMetadata}</p>
                <p class="metadata">Fecha de Descarga: ${dataItem[id][0].date == undefined || null ? date : dataItem[id][0].date}</p>
                </div>
              </div>
              <div class="progress-container">
                <div class="progress progress-striped active">
                  <div class="progress-bar progress-bar-inverse" id="progressBarInner" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: ${dataItem[id][0].progressBarInner === undefined || null ? progressBarInner : dataItem[id][0].progressBarInner}%;">${dataItem[id][0].progressBarInner === undefined || null ? progressBarInner : dataItem[id][0].progressBarInner}% 0.08MB/s</div>
                </div>
                <p id="progressDetails" class="progress-details">${dataItem[id][0].progressDetails === undefined || null ? progressDetails : dataItem[id][0].progressDetails}</p>
                <button id="cancelButton" class="cancel-button" style="visibility: visible;">Cancelar</button>
                <button id="reanudedButton" class="reanuded-button" style="visibility: visible;">Reanudar</button>
              </div>
            </div>`
        })
        localStorage.setItem('downloadItems', JSON.stringify(downloadItems));
      } else {
        socket.emit('link_download', JSON.stringify({
          link,
          filename,
          ID: id
        }));
        pausedButton.id = 'pausedButton';
        pausedButton.className = "paused-button";
        pausedButton.textContent = "Pausar";
        const downloadItems = localStorage.getItem('downloadItems') != null ? JSON.parse(localStorage.getItem('downloadItems')) : []
        downloadItems.splice(downloadItems.findIndex(data => {data.id === id}), 1)
        localStorage.setItem('downloadItems', JSON.stringify(downloadItems));
      }
    });
  } else {
    console.error("No se encontró el elemento .downloads-section en el documento.");
  }
}

